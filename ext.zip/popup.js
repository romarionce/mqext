let input = document.querySelector('input')

input.addEventListener('change', e=> setValue(e.target.value))

async function setValue(value){
  await browser.storage.local.set({value});
  console.log('HELLO')
}

async function init(){
  let {value} = browser.local.storage.get('value');
  let p = document.querySelector('#romar')
  console.log('HELLO')
  if(!value){
    value = 0
  }
  p.innerHTML = value +'%'
  input.value = value;
  setValue(value)
}

init().catch(e=>console.error(e))